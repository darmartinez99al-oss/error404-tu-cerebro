ERROR 404: TU CEREBRO — PROYECTO MÓVIL PARA ANDROID E IOS

ESTE ARCHIVO ES EL PROYECTO FUENTE, NO UN APK/IPA YA COMPILADO.

Incluye:
- Juego web adaptable a móviles.
- Tienda de prueba con monedas virtuales y objetos.
- Configuración inicial de Capacitor para preparar Android e iOS.

IMPORTANTE:
- La tienda usa moneda virtual local. No hay compras con dinero real.
- No hay anuncios integrados todavía.
- El progreso guardado en el navegador puede no sincronizarse automáticamente entre dispositivos.

COMPILACIÓN (normalmente requiere ordenador o servicio de compilación en la nube):
1. Instalar Node.js LTS.
2. Descomprimir el ZIP y abrir una terminal en la carpeta del proyecto.
3. Ejecutar: npm install
4. Android: npx cap add android && npx cap sync android
5. Abrir Android Studio con: npx cap open android
6. iOS: requiere macOS/Xcode para el flujo habitual: npx cap add ios && npx cap sync ios && npx cap open ios

SIN ORDENADOR:
Se puede investigar un servicio de compilación en la nube para Android. Para iOS, el servicio necesita gestionar firma y distribución de Apple; normalmente hace falta una cuenta Apple Developer para distribuir por TestFlight/App Store. No introduzcas contraseñas ni certificados privados en servicios desconocidos.

PUBLICACIÓN:
La publicación requiere pruebas, iconos, capturas, política de privacidad y cumplir las normas actuales de Google Play y Apple. Las compras reales deben implementarse con Google Play Billing y Apple StoreKit. Los anuncios deben integrarse mediante un SDK compatible y respetar consentimiento/privacidad.
